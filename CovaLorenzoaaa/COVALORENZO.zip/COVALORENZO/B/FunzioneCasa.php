
<?php

function FunzioneCasa(int $metratura, int $piano) {
    $ARR_metratura= array(7/$metratura + rand(1))
}
FunzioneCasa(5, 10);
echo . FunzioneCasa(7, 13) . "<br>";
FunzioneCasa(2, 4);
echo . FunzioneCasa(5, 8) . "<br>";
FunzioneCasa(1, 11);

?>
